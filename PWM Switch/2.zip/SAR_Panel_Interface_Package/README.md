# SAR panel interface package

Draft, 17 Nov 2026. Material for the firm that builds the solar panel and installs the SAR board.

## What is in this folder

- `SAR_Panel_Interface_Slides.pptx`: 21 plain slides. Slides 1 to 15 are for the panel team. Slides 16 to 21 are backup on how the SAR works; delete them if they are not wanted.
- `figures_png/`: every figure as an image. F01 to F12 belong to the panel team slides, B01 to B03 to the backup.
- `figures_svg/`: the drawn figures as vector files (F01 to F08, B01 to B03).
- `tables_png/`: every table as an image, T01 to T14.

## How to change things

- In the deck, each figure is one group of ordinary PowerPoint shapes. Select it and ungroup (Ctrl+Shift+G) to move a line, recolour a cell or retype a label. Regroup when done.
- Tables are ordinary PowerPoint tables. Text is in ordinary text boxes. Colours and the font come from the deck theme.
- The SVG files open in Visio, Inkscape or Illustrator. In PowerPoint, insert one as a picture and choose Convert to Shape.
- F09 to F12 (code key, circuit cards, safe states, voltage cards) are built from shapes in the deck; they come as PNG but not as SVG.
- Each slide has speaker notes saying what the slide is for.

## Basis and assumptions

- Panel views are from the back, with STR 7 at the left, as in the wiring diagram Rev B.
- Scale: a cell is 7 cm wide and 4 cm tall, so the cell area is 49 x 40 cm. The SAR board is drawn at 4 x 10 cm and each connector at about 1.3 x 5.3 cm. Connector positions and lead routes are indicative.
- The work split assumes the panel team mounts J1 and J2, lays the J2 ribbon and solders the six leads.
- Board and lead values are proposals.
- The no-battery watt figures are estimates to confirm on the bench.
- The "Blocking diodes" line on slide 15 is new: the part type for DB1 to DB4 has not been stated anywhere yet.

# Slide guide

One block per slide: the title to use, the visual, the text on the slide, and what the slide is for.

## Slide 1: SAR interface for the solar panel build

Subtitle: What the panel has to provide, and how the Solar Array Shunt Regulator (SAR) attaches to it. Draft, 17 Nov 2026.

Visuals: F03 (as a cover picture)

Purpose: Cover. The picture is the panel back with the SAR in place; it is explained on slide 8.

## Slide 2: We deliver one tested SAR; you build the panel and connect it

Visuals: F08 hand-over flow

Text on the slide:

- One SAR per panel, eight panels.
- Delivered to you: the SAR board with J1, J2, their wires and six labelled flying leads, safe-to-mate tested as one assembly.
- Your part: wire the strings into three circuits, bond the board, land the six leads, wire the test points, test the panel.
- Assumed yours, to confirm: mounting J1 and J2, laying the J2 ribbon and soldering the six leads.

Purpose: Sets the split of work. Steps 1 to 3 are ours, 4 to 9 are the panel team. Step 9 points to the caution slides.

## Slide 3: Recommended string polarities: + at the top on four strings, at the bottom on three

Visuals: F01 panel string polarities

Text on the slide:

- Back view of the panel: STR 7 is at the left, STR 1 at the right.
- Seven strings of ten cells. A cell is 7 cm wide and 4 cm tall.
- STR 7 to STR 4 have the + end at the top. STR 3 to STR 1 have it at the bottom.
- A pad takes the code of its end cell: cell 10 is the + end, cell 1 the − end.

Purpose: The polarity picture, drawn to the 7 x 4 cm cell. Flipping STR 3, 2 and 1 keeps the series links short.

## Slide 4: Each string has a position name and an electrical code

Visuals: Code key (native shapes); T01 string names

Text on the slide:

- The code gives the electrical place of a cell, not its position on the panel, so both names are used.

Purpose: STR 1 to 7 say where a string sits. The code says which circuit, branch and series element it belongs to.

## Slide 5: The panel delivers three circuits: 10S1P, 20S2P and 20S1P

Visuals: Circuit cards (native shapes); T02 circuits

Text on the slide:

- The strings may be wired differently, as long as the SAR receives these three circuits.
- The layout shown is recommended: it puts all four blocking diodes on the left, next to the SAR.
- One blocking diode at the + end of each branch, four in all. CKT 2 has two branches in parallel.

Purpose: This is the requirement. The layout on the other slides is one way to meet it, and the one we recommend.

## Slide 6: Panel wiring: four blocking diodes, three series links, six nets

Visuals: F02 panel wiring

Text on the slide:

- DB1 to DB4: anode on the + pad, cathode to the net.
- Series links: 3-1-1-1 to 3-1-2-10, 2-2-1-1 to 2-2-2-10 and 2-1-1-1 to 2-1-2-10.
- Joints: the DB2 and DB3 cathodes, and pads 2-2-2-1 and 2-1-2-1.
- The six nets are where the six SAR leads land.

Purpose: What the panel team builds: diodes, links, two joints. The six dots are the hand-off to the SAR leads.

## Slide 7: The SAR board: 40 × 100 mm, bonded flat, three leads at each end

Visuals: F04 SAR board outline; T03 board values

Text on the slide:

- All board values are proposals until confirmed.

Purpose: What arrives. The panel team needs the footprint, the height, the bond face and where the leads leave.

## Slide 8: The SAR sits behind STR 7, with J1 at the left and J2 at the right

Visuals: F03 SAR on the panel

Text on the slide:

- Board: behind STR 7, between pads 1-1-1-10 and 1-1-1-1, top end toward 1-1-1-10.
- J1: middle of the left side, beside the board, with its 22 wires.
- J2: middle of the right side. Its 9-wire ribbon crosses the panel back.
- Power leads leave the top end of the board and return leads the bottom end. CKT2_RTN and CKT3_RTN are the longest runs and cross over the ribbon.
- Cells, board and connectors are to scale. Lead routes and connector positions are indicative.

Purpose: How our hardware meets the panel wiring. Same panel picture as slide 6, with the SAR, J1, J2 and the six leads added.

## Slide 9: Six labelled leads: three to diode cathodes, three to return pads

Visuals: T04 flying leads; T05 lead wire

Text on the slide:

- All six leads are white: the printed sleeve is the only identification.

Purpose: The solder list for the six leads, and what the wire is.

## Slide 10: J1 carries power out and the returns, and comes pre-wired

Visuals: F05 J1 contact map; T06 J1 nets

Text on the slide:

- 25-contact D-subminiature, delivered wired to the board with 22 wires.
- Contacts 1, 7 and 20 are not connected. The shell goes to chassis.
- A current is the most the SAR can put on that net, shared by its contacts.
- Mounting J1 is assumed to be the panel team’s task.

Purpose: J1 is ours and arrives wired. The panel team needs the map for mounting and for its own tests.

## Slide 11: J2 comes with nine wires; its eight test point contacts are yours

Visuals: F06 J2 contact map; T07 J2 nets

Text on the slide:

- Same connector type as J1, delivered with nine wires in one ribbon.
- Contacts 6, 9, 10, 12, 13, 22, 23 and 25 are the test points: unwired at delivery, yours to wire.
- Contacts 1, 4, 7, 11, 16, 20, 21 and 24 are not connected. The shell goes to chassis.

Purpose: J2 arrives with the command, return and sensor wires. The eight test point contacts are left open for the panel team.

## Slide 12: Each test point pair reads one branch, ahead of its blocking diode

Visuals: F07 test point taps; T08 test point pads

Text on the slide:

- You choose which J2 pair serves which branch, the routing and the wire.
- Live whenever the panel is lit: up to about 55 V on a 20-cell branch.
- Not protected: a short across a pair carries the branch current, up to 0.55 A.

Purpose: P goes ahead of the diode so the two CKT 2 branches can be read separately. N goes on the return pad of the same branch.

## Slide 13: Never light the strings with the bus down and the commands open

Visuals: Safe-state cards (native shapes); T09 cautions, protecting the SAR

Purpose: The caution that protects the SAR. Three safe states and one that is not allowed. To tie a command to return at J2: contacts 2 and 14 (CKT 2) or 3 and 15 (CKT 3) to contact 5, 17 or 18.

## Slide 14: Without the battery nothing clamps the outputs: treat J1 as live

Visuals: Voltage and current cards (native shapes); T10 cautions, people and equipment

Purpose: The cautions that protect people and test equipment. The 55 V is at room temperature; it is higher when the cells are cold.

## Slide 15: Points to agree with the panel team

Visuals: T11 points to agree

Purpose: Closing slide: what we need back. Edit freely; the blocking diode line is new and not from the ICD.

## Slide 16 (backup): Backup: SAR internals

Subtitle: Not needed by the panel team. Kept for our own use and for questions.

Visuals: none

Purpose: Divider. Everything after this slide explains how the SAR works.

## Slide 17 (backup): Backup: what the SAR connects to

Visuals: B01 interfaces at a glance

Text on the slide:

- PWR_RTN returns on J1 and J2 and meets at one point on the SAR.
- AUX_HTR_RTN carries only the CKT 1 return and is not tied to PWR_RTN on the SAR.
- Only the connector shells reach chassis. Isolation is more than 10 MΩ from every net to chassis.

Purpose: Context only: the EPS side of J1 and J2.

## Slide 18 (backup): Backup: SAR circuit

Visuals: B02 SAR circuit

Text on the slide:

- Q2 and Q1 shunt CKT 2 and CKT 3 to return.
- D1 to D4 pass the unshunted current to the bus and the heaters.
- Each gate is pulled up to BATT_BUS_PWR through 24.2 kΩ and clamped at 4.7 V. The command line joins at the clamp.
- CKT 1 goes straight to AUX_HTR_PWR and has no shunt.

Purpose: Internal detail. Explains why the gate bias depends on the bus.

## Slide 19 (backup): Backup: why the SAR needs the bus or the commands when lit

Visuals: B03 battery versus no battery

Text on the slide:

- With the battery, the bus holds the gate at 4.7 V and the FET is fully on: 0.2 V or less across it.
- Without it, the array is the only gate supply and the FET settles partly on at about 2 to 4 V.
- The watt figures are estimates to confirm on the bench.

Purpose: The reason behind slide 13.

## Slide 20 (backup): Backup: terms

Visuals: T12 terms

Purpose: Glossary from the ICD.

## Slide 21 (backup): Backup: command lines and interface limits

Visuals: T13 shunt command line; T14 interface limits

Purpose: EPS-side values from the ICD.
