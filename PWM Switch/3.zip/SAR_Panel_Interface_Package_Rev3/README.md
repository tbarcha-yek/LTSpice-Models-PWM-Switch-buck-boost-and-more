# SAR panel interface package, Rev 3

Draft, 18 Nov 2026. Material for the firm that builds the solar panel and installs the SAR board.
Rev 3 replaces the first package and the Rev 2 panel figures.

## What changed in Rev 3

- The SAR is now the board with its flying leads, and nothing else. J1, J2, the temperature sensor and the CKT 1 wiring are outside it.
- The SAR has 14 leads: CKT2_PWR, CKT3_PWR, CKT2_RTN and CKT3_RTN to the strings; AUX_HTR_PWR, MAIN_HTR_PWR, two BATT_BUS_PWR and two PWR_RTN to J1; CKT2_CTRL, CKT3_CTRL and two PWR_RTN to J2.
- The two BATT_BUS_PWR leads stay separate on the SAR and are joined at J1 contacts 2 to 6. CKT2_RTN and CKT3_RTN stay separate leads.
- CKT1_PWR and CKT1_RTN are panel wiring, straight to J1. J1 and J2 pin assignments are unchanged.
- New slide 3 and figure F13 show the SAR boundary. The backup "interfaces at a glance" slide and figure B01 are gone.
- Redrawn: F02, F03, F04, F08, F13 (new), B02. Relabelled: F06, F07. F01 is the Rev 2 polarity figure. F05 and B03 are unchanged.
- Tables revised: T02, T03, T04, T06, T07, T09, T10, T11, T12. Unchanged: T01, T05, T08, T13, T14.

## What is in this folder

- `SAR_Panel_Interface_Slides_Rev3.pptx`: 21 plain slides. Slides 1 to 16 are for the panel team. Slides 17 to 21 are backup on how the SAR works; delete them if they are not wanted.
- `figures_png/`: every figure as an image. F01 to F13 belong to the panel team slides, B02 and B03 to the backup.
- `figures_svg/`: the drawn figures as vector files (F01 to F08, F13, B02, B03).
- `tables_png/`: every table as an image, T01 to T14.

## How to change things

- In the deck, each figure is one group of ordinary PowerPoint shapes. Select it and ungroup (Ctrl+Shift+G) to move a line, recolour a cell or retype a label. Regroup when done.
- Tables are ordinary PowerPoint tables. Text is in ordinary text boxes. Colours and the font come from the deck theme.
- The SVG files open in Visio, Inkscape or Illustrator. In PowerPoint, insert one as a picture and choose Convert to Shape.
- F09 to F12 (code key, circuit cards, safe states, voltage cards) are built from shapes in the deck; they come as PNG but not as SVG.
- Each slide has speaker notes saying what the slide is for.

## Basis and assumptions

- Panel views are from the back, with STR 7 at the left.
- Scale: a cell is 7 cm wide and 4 cm tall, so the cell area is 49 x 40 cm. The SAR board is drawn at 4 x 10 cm and each connector at about 1.3 x 5.3 cm. Connector positions and lead routes are indicative.
- Lead count: 14, with one lead per net except PWR_RTN, which has two leads to J1 and two to J2. This count is an assumption.
- Gate bias: each shunt gate is assumed to take its pull-up from its own BATT_BUS_PWR lead (Q2 from the CKT 2 lead, Q1 from the CKT 3 lead). The caution row "One BATT_BUS_PWR lead not connected" on slide 14 and the backup circuit B02 rest on this.
- Lead exits: CKT2 leads at 12.0 mm and CKT3 leads at 28.0 mm from datum A on the short edges are proposals. Positions along the long edges are open.
- J1, J2 and the temperature sensor are taken to be supplied, mounted and wired by the panel team.
- Board and lead values are proposals. The no-battery watt figures are estimates to confirm on the bench.
- Not updated to this boundary: the ICD document, the wiring diagram Rev B and the safe-to-mate test plan.

# Slide guide

One block per slide: the title to use, the visual, the text on the slide, and what the slide is for.

## Slide 1: SAR interface for the solar panel build

Subtitle: What the panel has to provide, and how the Solar Array Shunt Regulator (SAR) board and its leads attach to it. Draft, 18 Nov 2026.

Visuals: F03 (as a cover picture)

Purpose: Cover. The picture is the panel back with the SAR board in place; it is explained on slide 9.

## Slide 2: We deliver the tested SAR board with its leads; you build the panel and connect it

Visuals: F08 hand-over flow

Text on the slide:

- One SAR per panel, eight panels.
- Delivered to you: the SAR board with 14 labelled flying leads, safe-to-mate tested.
- Your part: wire the strings into three circuits, bond the board, land the 14 leads, wire CKT 1, the temperature sensor and the test points to J1 and J2, then test the panel.
- J1, J2 and the temperature sensor are not part of the SAR.

Purpose: Sets the split of work. Steps 1 to 3 are ours, 4 to 9 are the panel team. Step 9 points to the caution slides.

## Slide 3: The SAR is the board and its 14 leads; J1, J2, CKT 1 and the sensor are the panel’s

Visuals: F13 SAR boundary

Text on the slide:

- From the panel into the SAR: CKT2_PWR, CKT2_RTN, CKT3_PWR and CKT3_RTN.
- From the SAR to J1: AUX_HTR_PWR, MAIN_HTR_PWR, two BATT_BUS_PWR leads and two PWR_RTN leads.
- Between J2 and the SAR: CKT2_CTRL, CKT3_CTRL and two PWR_RTN leads.
- Not through the SAR: CKT1_PWR and CKT1_RTN go straight to J1; the temperature sensor and the test points go straight to J2.
- J1 and J2 pin assignments are unchanged.

Purpose: The boundary of our delivery. Everything drawn bold is a SAR flying lead; everything thin is panel wiring.

## Slide 4: Recommended string polarities: + at the top on four strings, at the bottom on three

Visuals: F01 panel string polarities

Text on the slide:

- Back view of the panel: STR 7 is at the left, STR 1 at the right.
- Seven strings of ten cells. A cell is 7 cm wide and 4 cm tall.
- STR 7 to STR 4 have the + end at the top. STR 3 to STR 1 have it at the bottom.
- A pad takes the code of its end cell: cell 10 is the + end, cell 1 the − end.

Purpose: The polarity picture, drawn to the 7 x 4 cm cell. Flipping STR 3, 2 and 1 keeps the series links short.

## Slide 5: Each string has a position name and an electrical code

Visuals: F09 code key (native shapes); T01 string names

Text on the slide:

- The code gives the electrical place of a cell, not its position on the panel, so both names are used.

Purpose: STR 1 to 7 say where a string sits. The code says which circuit, branch and series element it belongs to.

## Slide 6: The panel delivers three circuits: 10S1P, 20S2P and 20S1P

Visuals: F10 circuit cards (native shapes); T02 circuits

Text on the slide:

- The strings may be wired differently, as long as these three circuits result.
- The layout shown is recommended: it puts all four blocking diodes on the left, next to the SAR board.
- One blocking diode at the + end of each branch, four in all. CKT 2 has two branches in parallel.
- CKT 2 and CKT 3 go to the SAR. CKT 1 does not: it goes straight to J1.

Purpose: This is the requirement. The layout on the other slides is one way to meet it, and the one we recommend.

## Slide 7: Panel wiring: four blocking diodes, three series links, six nets

Visuals: F02 panel wiring

Text on the slide:

- DB1 to DB4: anode on the + pad, cathode to the net.
- Series links: 3-1-1-1 to 3-1-2-10, 2-2-1-1 to 2-2-2-10 and 2-1-1-1 to 2-1-2-10.
- Joints: the DB2 and DB3 cathodes, and pads 2-2-2-1 and 2-1-2-1.
- Four nets are where the SAR leads land: CKT2 and CKT3, PWR and RTN.
- CKT1_PWR and CKT1_RTN continue to J1 as panel wiring.

Purpose: What the panel team builds: diodes, links, two joints. Four nets hand off to SAR leads; the two CKT 1 nets go on to J1.

## Slide 8: The SAR board: 40 × 100 mm, bonded flat, 14 flying leads

Visuals: F04 SAR board outline; T03 board values

Text on the slide:

- All board values are proposals until confirmed.

Purpose: What arrives. The panel team needs the footprint, the height, the bond face and where the leads leave.

## Slide 9: SAR board behind STR 7; leads to the strings, J1 and J2

Visuals: F03 SAR on the panel

Text on the slide:

- Board: behind STR 7, between pads 1-1-1-10 and 1-1-1-1, top end toward 1-1-1-10.
- Four leads go to the strings: CKT2_PWR and CKT3_PWR from the top end, CKT2_RTN and CKT3_RTN from the bottom end. The return leads are the longest runs.
- Six leads go to J1, beside the board. Four go to J2, across the panel back.
- CKT1_PWR and CKT1_RTN are panel wiring, straight to J1.
- Cells, board and connectors are to scale. Lead routes and connector positions are indicative.

Purpose: How our hardware meets the panel wiring. Same panel picture as slide 7, with the SAR board and its leads added. Bold lines are SAR leads, thin lines are panel wiring.

## Slide 10: 14 labelled leads: four to the strings, six to J1, four to J2

Visuals: T04 flying leads; T05 lead wire

Text on the slide:

- All 14 leads are white: the printed sleeve is the only identification.

Purpose: The landing list for the 14 leads, and what the wire is. The two BATT_BUS_PWR leads stay separate until J1.

## Slide 11: J1 is on your side: same pinout, six SAR leads and the CKT 1 wires land on it

Visuals: F05 J1 contact map; T06 J1 nets

Text on the slide:

- 25-contact D-subminiature. Not part of the SAR; pin assignments unchanged.
- The two BATT_BUS_PWR leads meet only here, on contacts 2 to 6.
- AUX_HTR_PWR meets CKT1_PWR on contacts 17 to 19. CKT1_RTN lands on 13, 24 and 25.
- Contacts 1, 7 and 20 are not connected. The shell goes to chassis.
- A current is the most the panel can put on that net, shared by its contacts.

Purpose: J1 is the panel team’s connector. The map says where each SAR lead and each CKT 1 wire lands.

## Slide 12: J2 is on your side too: four SAR leads, the sensor and the test points

Visuals: F06 J2 contact map; T07 J2 nets

Text on the slide:

- Same connector type as J1. Not part of the SAR; pin assignments unchanged.
- Four SAR leads land here: CKT2_CTRL, CKT3_CTRL and two PWR_RTN.
- The temperature sensor is a panel part: its wires go to contacts 8 and 19.
- Contacts 6, 9, 10, 12, 13, 22, 23 and 25 are the test points.
- Contacts 1, 4, 7, 11, 16, 20, 21 and 24 are not connected. The shell goes to chassis.

Purpose: J2 is the panel team’s connector. Four SAR leads land on it; the sensor and the test points are panel wiring.

## Slide 13: Each test point pair reads one branch, ahead of its blocking diode

Visuals: F07 test point taps; T08 test point pads

Text on the slide:

- You choose which J2 pair serves which branch, the routing and the wire.
- Live whenever the panel is lit: up to about 55 V on a 20-cell branch.
- Not protected: a short across a pair carries the branch current, up to 0.55 A.

Purpose: P goes ahead of the diode so the two CKT 2 branches can be read separately. N goes on the return pad of the same branch.

## Slide 14: Never light the strings with the bus down and the commands open

Visuals: F11 safe-state cards (native shapes); T09 cautions, protecting the SAR

Purpose: The caution that protects the SAR. Three safe states and one that is not allowed. To tie a command to return at J2: contacts 2 and 14 (CKT 2) or 3 and 15 (CKT 3) to contact 5, 17 or 18. The BATT_BUS_PWR row assumes each shunt gate is biased from its own lead.

## Slide 15: Without the battery nothing clamps the outputs: treat J1 and loose lead ends as live

Visuals: F12 voltage and current cards (native shapes); T10 cautions, people and equipment

Purpose: The cautions that protect people and test equipment. The 55 V is at room temperature; it is higher when the cells are cold.

## Slide 16: Points to agree with the panel team

Visuals: T11 points to agree

Purpose: Closing slide: what we need back. Edit freely. The scope, connector and sensor lines assume the panel team supplies J1, J2 and the sensor.

## Slide 17 (backup): Backup: SAR internals

Subtitle: Not needed by the panel team. Kept for our own use and for questions.

Visuals: none

Purpose: Divider. Everything after this slide explains how the SAR works.

## Slide 18 (backup): Backup: SAR circuit

Visuals: B02 SAR circuit

Text on the slide:

- Q2 and Q1 shunt CKT 2 and CKT 3 to return.
- D2, D3 and D4 pass unshunted CKT 2 current to the heaters and the bus. D1 does the same for CKT 3.
- Each gate is pulled up to its own BATT_BUS_PWR lead through 24.2 kΩ and clamped at 4.7 V. The command line joins at the clamp.
- The two BATT_BUS_PWR leads are joined only at J1.
- CKT 1 does not pass through the SAR.

Purpose: Internal detail. Explains why the gate bias depends on the bus, and why both BATT_BUS_PWR leads have to be landed. The gate bias taken per lead is an assumption to confirm.

## Slide 19 (backup): Backup: why the SAR needs the bus or the commands when lit

Visuals: B03 battery versus no battery

Text on the slide:

- With the battery, the bus holds the gate at 4.7 V and the FET is fully on: 0.2 V or less across it.
- Without it, the array is the only gate supply and the FET settles partly on at about 2 to 4 V.
- The watt figures are estimates to confirm on the bench.

Purpose: The reason behind slide 14.

## Slide 20 (backup): Backup: terms

Visuals: T12 terms

Purpose: Glossary.

## Slide 21 (backup): Backup: command lines and interface limits

Visuals: T13 shunt command line; T14 interface limits

Purpose: EPS-side values.
